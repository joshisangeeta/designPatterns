/**
 * 
 */
package com.sj;

/**
 * @author HP
 *
 */
public class RealImage implements Image {
 
	RealImage image;
    String imageName;
	
	
	
	
	public String getImageName() {
		return imageName;
	}




	public void setImageName(String imageName) {
		this.imageName = imageName;
	}




	public RealImage() {
		super();
		int i=0;
		long t1 = System.currentTimeMillis();
		while(i<1000000000) {
			i++;
		}
		long t2= System.currentTimeMillis();
		// TODO Auto-generated constructor stub
		System.out.println("Loading Time:"+(t2-t1));
	}




	@Override
	public Image loadImage() {
		// TODO Auto-generated method stub
		if (image==null)
		image= new RealImage();
		return image;
	}
	
	
	
	

}
