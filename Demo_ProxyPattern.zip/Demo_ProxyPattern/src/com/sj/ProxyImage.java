/**
 * 
 */
package com.sj;

/**
 * @author HP
 *
 */
public class ProxyImage implements Image {
	RealImage realImage;
    String imageName;
	
	
	
	
	public String getImageName() {
		return imageName;
	}




	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	



	public ProxyImage(String imageName) {
		super();
		this.imageName = imageName;
	}




	@Override
	
		public Image loadImage() {
			// TODO Auto-generated method stub
			
			if (realImage==null)
			  realImage=new RealImage();
			
			
			return realImage;
		}
		



}
