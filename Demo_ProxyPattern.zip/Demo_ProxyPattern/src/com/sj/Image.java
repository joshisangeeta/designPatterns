/**
 * 
 */
package com.sj;

/**
 * @author HP
 *
 */
public interface Image {
	
	public Image loadImage();

}
