/**
 * 
 */
package com.sj;

/**
 * @author HP
 *
 */
public class ImageLoader {

	public static void main(String[] args) {
		
		ProxyImage image = new ImageLoader().getImage();
		
		System.out.println(image.getImageName());
		
		image.loadImage();
		
		 		
	}
	
	ProxyImage getImage() {
		
		return new ProxyImage("someImage");
	}
	
	
	
	

}
