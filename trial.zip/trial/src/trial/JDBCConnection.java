package trial;

public class JDBCConnection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
             Class.forName("driverName");
             ------
      
		  }
	    catch(Exception e) {
			
		}
	
	}

}
