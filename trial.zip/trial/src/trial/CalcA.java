package trial;

public class CalcA {
	String s1;
	String s2;
	int[] integers= {1,2,3,4};
	
	
	public void calculate() {
		
		for(int i=0;i<integers.length;i++) {
			
			// code for adding  elements of array
		}
		
	}
   public void addStrings() {
		
	   //code for concatinating multiple strings
		s1 =s1.concat(s2);
	}

	
}
