package trial;

public class vehicle {
	String Title;
	final int NO_OF_WHEELS = 4;
	public void setTitle(String title)
	{
		this.Title =title;
	}	
	
}
