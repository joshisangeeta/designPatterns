/**
 * 
 */
package trial;

/**
 * @author HP
 *
 */
public class Main {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    	      A a1 = new B();
		
	}
}
class A {
	int a;
	A(int a){
		this.a =a;
	}
}

class B extends A{
 	B(){
 //1		
 		super()
	}
}
