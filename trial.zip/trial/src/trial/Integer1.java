package trial;

public class Integer1 {
  
	
	Integer i;
	public Integer1(int i) {
		this.i=i;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	   Integer i = new Integer(5);
	
	    System.out.println(i);
	}

}
